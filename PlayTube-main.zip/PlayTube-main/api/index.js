import { app } from "../app.js";
export default app;
console.log("Yash Zanzarukiya");
